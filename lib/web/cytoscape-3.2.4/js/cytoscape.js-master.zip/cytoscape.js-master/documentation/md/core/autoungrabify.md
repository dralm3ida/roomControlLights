## Examples

Enable:
```js
cy.autoungrabify( true );
```

Disable:
```js
cy.autoungrabify( false );
```