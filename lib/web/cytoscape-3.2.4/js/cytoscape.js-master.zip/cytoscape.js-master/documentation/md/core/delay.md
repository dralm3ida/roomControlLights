## Examples

```js
cy
  .animate({
    fit: { eles: '#j' }
  })

  .delay(1000)

  .animate({
    fit: { eles: '#e' }
  })
;
```