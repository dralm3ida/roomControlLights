## Examples

Remove all classes:

```js
cy.nodes().classes(); // no classes
```

Replace classes:

```js
cy.nodes().classes('foo');
```
