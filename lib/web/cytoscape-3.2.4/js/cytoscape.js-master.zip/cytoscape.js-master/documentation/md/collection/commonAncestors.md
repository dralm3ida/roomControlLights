## Details

You can get the closest common ancestor via `nodes.commonAncestors().first()` and the farthest via `nodes.commonAncestors().last()`, because the common ancestors are in descending order of closeness.