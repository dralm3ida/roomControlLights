## Examples

```js
cy.getElementById('j');
```

Using the shorter alias:

```js
cy.$id('j');
```
