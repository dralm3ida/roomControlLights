## Examples

```js
cy.$('#j').lock();
```