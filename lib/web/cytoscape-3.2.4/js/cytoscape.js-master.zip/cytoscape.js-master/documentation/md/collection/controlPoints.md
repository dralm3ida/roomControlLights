## Details

While the control points may be specified relatively in the CSS, this function returns the absolute model positions of the control points. The points are specified in the order of source-to-target direction.

This function works for bundled beziers, but it is not applicable to the middle, straight-line edge in the bundle.
