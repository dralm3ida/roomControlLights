## Examples

```js
cy.$('#j, #e, #k').symdiff('#j, #g');
```