## Details

If no collection is specified, then the graph is fit to all nodes and edges in the graph.

## Examples

Fit the graph on nodes `j` and `e`:
```js
cy.fit( cy.$('#j, #e') );
```
