## Examples

```js
console.log( 'j has class `foo` : '  + cy.$('#j').hasClass('foo') );
```