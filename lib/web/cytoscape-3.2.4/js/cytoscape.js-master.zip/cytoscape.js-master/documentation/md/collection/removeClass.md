## Examples

```js
cy.$('#j, #e').removeClass('foo');
```