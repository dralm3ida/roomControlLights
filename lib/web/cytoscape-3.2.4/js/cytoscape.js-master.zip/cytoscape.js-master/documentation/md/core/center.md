## Details

If no collection is specified, then the graph is centred on all nodes and edges in the graph.

## Examples

Centre the graph on node `j`:
```js
var j = cy.$("#j");
cy.center( j );
```
