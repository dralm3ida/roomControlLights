## Examples

```js
var j = cy.$('#j');
var e = cy.$('#e');

j.edgesTo(e);
```