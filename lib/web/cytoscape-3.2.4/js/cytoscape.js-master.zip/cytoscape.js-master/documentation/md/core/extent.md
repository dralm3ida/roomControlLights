## Details

This function returns a plain object bounding box with format `{ x1, y1, x2, y2, w, h }`.