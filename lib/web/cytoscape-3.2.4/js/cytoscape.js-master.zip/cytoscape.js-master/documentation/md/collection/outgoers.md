## Examples

Get outgoers of `j`:
```js
cy.$('#j').outgoers();
```