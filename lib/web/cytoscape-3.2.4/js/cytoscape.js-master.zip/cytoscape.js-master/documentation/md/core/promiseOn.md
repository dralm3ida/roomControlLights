## Examples

```js
cy.pon('tap').then(function( event ){
  console.log('tap promise fulfilled');
});
```
