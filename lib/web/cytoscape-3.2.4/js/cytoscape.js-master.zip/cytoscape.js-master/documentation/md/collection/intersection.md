## Examples

```js
var jNhd = cy.$('#j').neighborhood();
var eNhd = cy.$('#e').neighborhood();

jNhd.intersection( eNhd );
```