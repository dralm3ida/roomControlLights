## Details

Note that this function runs Kruskal's algorithm on the subset of the graph in the calling collection.


## Examples

```js
cy.elements().kruskal();
```