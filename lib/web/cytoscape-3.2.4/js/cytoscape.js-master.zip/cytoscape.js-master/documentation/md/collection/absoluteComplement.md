## Examples

```js
cy.$('#j').absoluteComplement();
```