## Details

Two edges are said to be codirected if they connect the same two nodes in the same direction: The edges have the same source and target.

## Examples

```js
cy.$('#je').codirectedEdges(); // only self in this case
```
