// set this to run just a single suite via `gulp benchmark-single`
// (useful when working on a specific function)
module.exports = require('../add.js');
